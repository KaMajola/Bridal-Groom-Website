(function() {
    'use strict';
    
    var menuBtn = document.getElementById('mobile-menu-btn');
    var mobileMenu = document.getElementById('mobile-menu');
    var menuIcon = document.getElementById('menu-icon');
    var isMenuOpen = false;
    
    function toggleMobileMenu() {
        isMenuOpen = !isMenuOpen;
        if (isMenuOpen) {
            mobileMenu.classList.remove('hidden');
            menuIcon.classList.remove('fa-bars');
            menuIcon.classList.add('fa-times');
            menuBtn.setAttribute('aria-expanded', 'true');
            menuBtn.setAttribute('aria-label', 'Close mobile navigation menu');
        } else {
            mobileMenu.classList.add('hidden');
            menuIcon.classList.remove('fa-times');
            menuIcon.classList.add('fa-bars');
            menuBtn.setAttribute('aria-expanded', 'false');
            menuBtn.setAttribute('aria-label', 'Open mobile navigation menu');
        }
    }
    
    if (menuBtn) {
        menuBtn.addEventListener('click', toggleMobileMenu);
    }
    
    function handleNavClick(e) {
        var href = this.getAttribute('href');
        if (href && href.startsWith('#')) {
            e.preventDefault();
            var targetEl = document.querySelector(href);
            if (targetEl) {
                var navHeight = document.querySelector('nav').offsetHeight;
                var targetPos = targetEl.getBoundingClientRect().top + window.pageYOffset - navHeight;
                
                window.scrollTo({
                    top: targetPos,
                    behavior: 'smooth'
                });
                
                if (isMenuOpen) {
                    toggleMobileMenu();
                }
                
                setTimeout(function() {
                    targetEl.setAttribute('tabindex', '-1');
                    targetEl.focus();
                }, 100);
            }
        }
    }
    
    var navLinks = document.querySelectorAll('a[href^="#"]');
    navLinks.forEach(function(link) {
        link.addEventListener('click', handleNavClick);
    });
    
    function validateEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function showError(fieldId, errorId, message) {
        var field = document.getElementById(fieldId);
        var errorSpan = document.getElementById(errorId);
        if (field && errorSpan) {
            field.classList.add('border-red-500');
            field.setAttribute('aria-invalid', 'true');
            errorSpan.textContent = message;
            errorSpan.classList.remove('hidden');
        }
    }
    
    function clearError(fieldId, errorId) {
        var field = document.getElementById(fieldId);
        var errorSpan = document.getElementById(errorId);
        if (field && errorSpan) {
            field.classList.remove('border-red-500');
            field.setAttribute('aria-invalid', 'false');
            errorSpan.classList.add('hidden');
            errorSpan.textContent = '';
        }
    }
    
    function validateForm() {
        var isValid = true;
        var nameField = document.getElementById('fullname');
        var emailField = document.getElementById('email');
        var subjectField = document.getElementById('subject');
        var messageField = document.getElementById('message');
        
        if (!nameField || nameField.value.trim().length < 2) {
            showError('fullname', 'name-error', 'Please enter your full name (at least 2 characters)');
            isValid = false;
        } else {
            clearError('fullname', 'name-error');
        }
        
        if (!emailField || !validateEmail(emailField.value)) {
            showError('email', 'email-error', 'Please enter a valid email address');
            isValid = false;
        } else {
            clearError('email', 'email-error');
        }
        
        if (!subjectField || !subjectField.value) {
            showError('subject', 'subject-error', 'Please select a subject');
            isValid = false;
        } else {
            clearError('subject', 'subject-error');
        }
        
        if (!messageField || messageField.value.trim().length < 10) {
            showError('message', 'message-error', 'Please enter a message (at least 10 characters)');
            isValid = false;
        } else {
            clearError('message', 'message-error');
        }
        
        return isValid;
    }
    
    var contactForm = document.getElementById('contact-form');
    if (contactForm) {
        var nameInput = document.getElementById('fullname');
        var emailInput = document.getElementById('email');
        var subjectInput = document.getElementById('subject');
        var messageInput = document.getElementById('message');
        var messageCount = document.getElementById('message-count');
        
        if (nameInput) {
            nameInput.addEventListener('blur', function() {
                if (this.value.trim().length < 2) {
                    showError('fullname', 'name-error', 'Please enter your full name (at least 2 characters)');
                } else {
                    clearError('fullname', 'name-error');
                }
            });
            nameInput.addEventListener('input', function() {
                if (this.value.trim().length >= 2) {
                    clearError('fullname', 'name-error');
                }
            });
        }
        
        if (emailInput) {
            emailInput.addEventListener('blur', function() {
                if (!validateEmail(this.value)) {
                    showError('email', 'email-error', 'Please enter a valid email address');
                } else {
                    clearError('email', 'email-error');
                }
            });
            emailInput.addEventListener('input', function() {
                if (validateEmail(this.value)) {
                    clearError('email', 'email-error');
                }
            });
        }
        
        if (subjectInput) {
            subjectInput.addEventListener('change', function() {
                if (this.value) {
                    clearError('subject', 'subject-error');
                }
            });
        }
        
        if (messageInput && messageCount) {
            messageInput.addEventListener('input', function() {
                var length = this.value.length;
                messageCount.textContent = length + ' / 1000 characters';
                if (length >= 10) {
                    clearError('message', 'message-error');
                }
            });
            messageInput.addEventListener('blur', function() {
                if (this.value.trim().length < 10) {
                    showError('message', 'message-error', 'Please enter a message (at least 10 characters)');
                } else {
                    clearError('message', 'message-error');
                }
            });
        }
        
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            var successMsg = document.getElementById('form-success');
            if (successMsg) {
                successMsg.classList.add('hidden');
            }
            
            if (validateForm()) {
                setTimeout(function() {
                    if (successMsg) {
                        successMsg.classList.remove('hidden');
                        successMsg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }
                    contactForm.reset();
                    if (messageCount) {
                        messageCount.textContent = '0 / 1000 characters';
                    }
                    
                    var allFields = contactForm.querySelectorAll('input, select, textarea');
                    allFields.forEach(function(field) {
                        field.setAttribute('aria-invalid', 'false');
                    });
                }, 100);
            } else {
                var firstError = contactForm.querySelector('[aria-invalid="true"]');
                if (firstError) {
                    firstError.focus();
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        });
    }
    
    function handleResize() {
        if (window.innerWidth >= 768 && isMenuOpen) {
            toggleMobileMenu();
        }
    }
    
    window.addEventListener('resize', handleResize);
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && isMenuOpen) {
            toggleMobileMenu();
        }
    });
    
    var newsletterForm = document.getElementById('newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var emailInput = document.getElementById('newsletter-email');
            if (emailInput && validateEmail(emailInput.value)) {
                alert('Thank you for subscribing to our newsletter!');
                emailInput.value = '';
            } else {
                alert('Please enter a valid email address.');
                if (emailInput) {
                    emailInput.focus();
                }
            }
        });
    }
    
    // Gallery Lightbox functionality
    var lightbox = document.getElementById('lightbox');
    var lightboxImage = document.getElementById('lightbox-image');
    var lightboxCaption = document.getElementById('lightbox-caption');
    var lightboxClose = document.getElementById('lightbox-close');
    var lightboxPrev = document.getElementById('lightbox-prev');
    var lightboxNext = document.getElementById('lightbox-next');
    var galleryItems = document.querySelectorAll('.gallery-item');
    var currentImageIndex = 0;
    var galleryImages = [];
    
    // Build gallery images array
    galleryItems.forEach(function(item, index) {
        var img = item.querySelector('img');
        if (img) {
            galleryImages.push({
                src: item.getAttribute('data-image'),
                caption: item.getAttribute('data-caption') || img.getAttribute('alt')
            });
            item.addEventListener('click', function() {
                openLightbox(index);
            });
        }
    });
    
    function openLightbox(index) {
        if (galleryImages.length === 0) return;
        currentImageIndex = index;
        updateLightboxImage();
        lightbox.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
    
    function closeLightbox() {
        lightbox.classList.add('hidden');
        document.body.style.overflow = '';
    }
    
    function updateLightboxImage() {
        if (galleryImages[currentImageIndex]) {
            lightboxImage.src = galleryImages[currentImageIndex].src;
            lightboxImage.alt = galleryImages[currentImageIndex].caption;
            lightboxCaption.textContent = galleryImages[currentImageIndex].caption;
        }
    }
    
    function showNextImage() {
        currentImageIndex = (currentImageIndex + 1) % galleryImages.length;
        updateLightboxImage();
    }
    
    function showPrevImage() {
        currentImageIndex = (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
        updateLightboxImage();
    }
    
    if (lightboxClose) {
        lightboxClose.addEventListener('click', closeLightbox);
    }
    
    if (lightboxNext) {
        lightboxNext.addEventListener('click', showNextImage);
    }
    
    if (lightboxPrev) {
        lightboxPrev.addEventListener('click', showPrevImage);
    }
    
    if (lightbox) {
        lightbox.addEventListener('click', function(e) {
            if (e.target === lightbox) {
                closeLightbox();
            }
        });
    }
    
    document.addEventListener('keydown', function(e) {
        if (!lightbox.classList.contains('hidden')) {
            if (e.key === 'Escape') {
                closeLightbox();
            } else if (e.key === 'ArrowRight') {
                showNextImage();
            } else if (e.key === 'ArrowLeft') {
                showPrevImage();
            }
        }
    });
    
    // Search functionality
    var searchBar = document.getElementById('search-bar');
    var searchBtn = document.getElementById('search-btn');
    var searchBtnMobile = document.getElementById('search-btn-mobile');
    var searchClose = document.getElementById('search-close');
    var searchInput = document.getElementById('search-input');
    var searchResults = document.getElementById('search-results');
    
    var searchableContent = [
        { title: 'Bridal Support', text: 'Dress fittings, makeup trials, and wedding planning assistance', section: 'services', link: '#services' },
        { title: 'Groom Services', text: 'Suits, traditional attire, and grooming services', section: 'services', link: '#services' },
        { title: 'Cultural Guidance', text: 'Expert advice on incorporating traditional South African customs', section: 'services', link: '#services' },
        { title: 'Venue & Decor', text: 'Beautiful venues and authentic South African decorations', section: 'services', link: '#services' },
        { title: 'Marriage Counseling', text: 'Pre-marital and couples counseling services', section: 'services', link: '#services' },
        { title: 'Community Programs', text: 'Outreach programs and donation drives', section: 'services', link: '#services' },
        { title: 'Success Stories', text: 'Real stories from couples we\'ve helped', section: 'stories', link: '#stories' },
        { title: 'Donation', text: 'Support our mission through financial or item donations', section: 'donate', link: '#donate' },
        { title: 'Volunteer', text: 'Share your time and skills to help couples', section: 'donate', link: '#donate' },
        { title: 'Contact Us', text: 'Get in touch with Bridal7Groom SA', section: 'contact', link: '#contact' }
    ];
    
    function openSearch() {
        if (searchBar) {
            searchBar.classList.remove('hidden');
            if (searchInput) {
                searchInput.focus();
            }
        }
    }
    
    function closeSearch() {
        if (searchBar) {
            searchBar.classList.add('hidden');
        }
        if (searchResults) {
            searchResults.classList.add('hidden');
        }
        if (searchInput) {
            searchInput.value = '';
        }
    }
    
    function performSearch(query) {
        if (!query || query.trim().length < 2) {
            if (searchResults) {
                searchResults.classList.add('hidden');
            }
            return;
        }
        
        var lowerQuery = query.toLowerCase();
        var matches = searchableContent.filter(function(item) {
            return item.title.toLowerCase().includes(lowerQuery) || 
                   item.text.toLowerCase().includes(lowerQuery);
        });
        
        if (searchResults) {
            searchResults.innerHTML = '';
            if (matches.length > 0) {
                matches.forEach(function(match) {
                    var resultItem = document.createElement('a');
                    resultItem.href = match.link;
                    resultItem.className = 'block p-4 hover:bg-gray-100 border-b border-gray-200';
                    resultItem.innerHTML = '<h4 class="font-semibold text-purple-600">' + match.title + '</h4><p class="text-sm text-gray-600 mt-1">' + match.text + '</p>';
                    resultItem.addEventListener('click', function(e) {
                        e.preventDefault();
                        closeSearch();
                        var targetEl = document.querySelector(match.link);
                        if (targetEl) {
                            var navHeight = document.querySelector('nav').offsetHeight;
                            var targetPos = targetEl.getBoundingClientRect().top + window.pageYOffset - navHeight;
                            window.scrollTo({ top: targetPos, behavior: 'smooth' });
                        }
                    });
                    searchResults.appendChild(resultItem);
                });
                searchResults.classList.remove('hidden');
            } else {
                var noResults = document.createElement('div');
                noResults.className = 'p-4 text-center text-gray-600';
                noResults.textContent = 'No results found';
                searchResults.appendChild(noResults);
                searchResults.classList.remove('hidden');
            }
        }
    }
    
    if (searchBtn) {
        searchBtn.addEventListener('click', openSearch);
    }
    
    if (searchBtnMobile) {
        searchBtnMobile.addEventListener('click', openSearch);
    }
    
    if (searchClose) {
        searchClose.addEventListener('click', closeSearch);
    }
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            performSearch(this.value);
        });
        
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeSearch();
            }
        });
    }
    
})();

